# Original inert qualification payload. Never imported.
VALUE = "other"
