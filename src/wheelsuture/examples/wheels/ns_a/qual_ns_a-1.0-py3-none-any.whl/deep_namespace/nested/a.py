# inert namespace A
