# inert module never imported
def main():
    return 0
