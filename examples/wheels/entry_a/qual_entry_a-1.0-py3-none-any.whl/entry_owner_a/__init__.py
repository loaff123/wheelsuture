# inert entry owner
