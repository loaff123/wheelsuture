# inert namespace B
